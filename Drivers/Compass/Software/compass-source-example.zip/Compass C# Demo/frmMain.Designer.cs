﻿namespace TestComPort
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdOpen = new System.Windows.Forms.Button();
            this.cmdSetup = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblDMagZ = new System.Windows.Forms.Label();
            this.lblDMagY = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.lblDMagX = new System.Windows.Forms.Label();
            this.lblDMag = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.lblDAccZ = new System.Windows.Forms.Label();
            this.lblDAccY = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.lblDAccX = new System.Windows.Forms.Label();
            this.lblDAcc = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lblDSPIErr = new System.Windows.Forms.Label();
            this.lblDGyroY = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lblDGyroX = new System.Windows.Forms.Label();
            this.lblDGyro = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.lblDRoll = new System.Windows.Forms.Label();
            this.lblDPitch = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblDTemp = new System.Windows.Forms.Label();
            this.lblDHeading = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblDDepth = new System.Windows.Forms.Label();
            this.lblDLifeCount = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmdExit = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cmdSendAsterisk = new System.Windows.Forms.Button();
            this.udOutFormat = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.cmdSendR = new System.Windows.Forms.Button();
            this.udOutRate = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.cmdSendS = new System.Windows.Forms.Button();
            this.udDeguass = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.cmdSendA = new System.Windows.Forms.Button();
            this.udAvgSamples = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cmdSendX = new System.Windows.Forms.Button();
            this.chkX05Depth = new System.Windows.Forms.CheckBox();
            this.chkX13SPI = new System.Windows.Forms.CheckBox();
            this.chkX12Life = new System.Windows.Forms.CheckBox();
            this.chkX11GyroVect = new System.Windows.Forms.CheckBox();
            this.chkX10Gyro = new System.Windows.Forms.CheckBox();
            this.chkX09AccVect = new System.Windows.Forms.CheckBox();
            this.chkX08Acc = new System.Windows.Forms.CheckBox();
            this.chkX07MagVect = new System.Windows.Forms.CheckBox();
            this.chkX06Mag = new System.Windows.Forms.CheckBox();
            this.chkX04Temp = new System.Windows.Forms.CheckBox();
            this.chkX03Roll = new System.Windows.Forms.CheckBox();
            this.chkX02Pitch = new System.Windows.Forms.CheckBox();
            this.chkX01Azimuth = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtMsgs = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.udOutFormat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.udOutRate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.udDeguass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.udAvgSamples)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdOpen
            // 
            this.cmdOpen.Location = new System.Drawing.Point(432, 9);
            this.cmdOpen.Name = "cmdOpen";
            this.cmdOpen.Size = new System.Drawing.Size(98, 30);
            this.cmdOpen.TabIndex = 0;
            this.cmdOpen.Text = "Open Port";
            this.cmdOpen.UseVisualStyleBackColor = true;
            this.cmdOpen.Click += new System.EventHandler(this.cmdOpen_Click);
            // 
            // cmdSetup
            // 
            this.cmdSetup.Location = new System.Drawing.Point(328, 9);
            this.cmdSetup.Name = "cmdSetup";
            this.cmdSetup.Size = new System.Drawing.Size(98, 30);
            this.cmdSetup.TabIndex = 2;
            this.cmdSetup.Text = "Configure...";
            this.cmdSetup.UseVisualStyleBackColor = true;
            this.cmdSetup.Click += new System.EventHandler(this.cmdSetup_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTitle.Location = new System.Drawing.Point(8, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(156, 19);
            this.lblTitle.TabIndex = 3;
            this.lblTitle.Text = "Compass C# Demo";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblDMagZ);
            this.groupBox1.Controls.Add(this.lblDMagY);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.lblDMagX);
            this.groupBox1.Controls.Add(this.lblDMag);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.lblDAccZ);
            this.groupBox1.Controls.Add(this.lblDAccY);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.label36);
            this.groupBox1.Controls.Add(this.lblDAccX);
            this.groupBox1.Controls.Add(this.lblDAcc);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.lblDSPIErr);
            this.groupBox1.Controls.Add(this.lblDGyroY);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.lblDGyroX);
            this.groupBox1.Controls.Add(this.lblDGyro);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.lblDRoll);
            this.groupBox1.Controls.Add(this.lblDPitch);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.lblDTemp);
            this.groupBox1.Controls.Add(this.lblDHeading);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.lblDDepth);
            this.groupBox1.Controls.Add(this.lblDLifeCount);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 198);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(613, 168);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Received Data ";
            // 
            // lblDMagZ
            // 
            this.lblDMagZ.AutoSize = true;
            this.lblDMagZ.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDMagZ.Location = new System.Drawing.Point(507, 137);
            this.lblDMagZ.Name = "lblDMagZ";
            this.lblDMagZ.Size = new System.Drawing.Size(32, 13);
            this.lblDMagZ.TabIndex = 35;
            this.lblDMagZ.Text = "xxxxx";
            // 
            // lblDMagY
            // 
            this.lblDMagY.AutoSize = true;
            this.lblDMagY.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDMagY.Location = new System.Drawing.Point(507, 114);
            this.lblDMagY.Name = "lblDMagY";
            this.lblDMagY.Size = new System.Drawing.Size(32, 13);
            this.lblDMagY.TabIndex = 34;
            this.lblDMagY.Text = "xxxxx";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(429, 137);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(27, 13);
            this.label27.TabIndex = 33;
            this.label27.Text = "Mz:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(429, 115);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(27, 13);
            this.label28.TabIndex = 32;
            this.label28.Text = "My:";
            // 
            // lblDMagX
            // 
            this.lblDMagX.AutoSize = true;
            this.lblDMagX.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDMagX.Location = new System.Drawing.Point(507, 92);
            this.lblDMagX.Name = "lblDMagX";
            this.lblDMagX.Size = new System.Drawing.Size(32, 13);
            this.lblDMagX.TabIndex = 31;
            this.lblDMagX.Text = "xxxxx";
            // 
            // lblDMag
            // 
            this.lblDMag.AutoSize = true;
            this.lblDMag.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDMag.Location = new System.Drawing.Point(507, 69);
            this.lblDMag.Name = "lblDMag";
            this.lblDMag.Size = new System.Drawing.Size(32, 13);
            this.lblDMag.TabIndex = 30;
            this.lblDMag.Text = "xxxxx";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(429, 92);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(27, 13);
            this.label31.TabIndex = 29;
            this.label31.Text = "Mx:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(429, 70);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(21, 13);
            this.label32.TabIndex = 28;
            this.label32.Text = "M:";
            // 
            // lblDAccZ
            // 
            this.lblDAccZ.AutoSize = true;
            this.lblDAccZ.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDAccZ.Location = new System.Drawing.Point(507, 48);
            this.lblDAccZ.Name = "lblDAccZ";
            this.lblDAccZ.Size = new System.Drawing.Size(32, 13);
            this.lblDAccZ.TabIndex = 27;
            this.lblDAccZ.Text = "xxxxx";
            // 
            // lblDAccY
            // 
            this.lblDAccY.AutoSize = true;
            this.lblDAccY.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDAccY.Location = new System.Drawing.Point(507, 25);
            this.lblDAccY.Name = "lblDAccY";
            this.lblDAccY.Size = new System.Drawing.Size(32, 13);
            this.lblDAccY.TabIndex = 26;
            this.lblDAccY.Text = "xxxxx";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(429, 48);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(25, 13);
            this.label35.TabIndex = 25;
            this.label35.Text = "Az:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(429, 26);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(25, 13);
            this.label36.TabIndex = 24;
            this.label36.Text = "Ay:";
            // 
            // lblDAccX
            // 
            this.lblDAccX.AutoSize = true;
            this.lblDAccX.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDAccX.Location = new System.Drawing.Point(299, 137);
            this.lblDAccX.Name = "lblDAccX";
            this.lblDAccX.Size = new System.Drawing.Size(32, 13);
            this.lblDAccX.TabIndex = 23;
            this.lblDAccX.Text = "xxxxx";
            // 
            // lblDAcc
            // 
            this.lblDAcc.AutoSize = true;
            this.lblDAcc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDAcc.Location = new System.Drawing.Point(299, 114);
            this.lblDAcc.Name = "lblDAcc";
            this.lblDAcc.Size = new System.Drawing.Size(32, 13);
            this.lblDAcc.TabIndex = 22;
            this.lblDAcc.Text = "xxxxx";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(221, 137);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(25, 13);
            this.label15.TabIndex = 21;
            this.label15.Text = "Ax:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(221, 115);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(19, 13);
            this.label16.TabIndex = 20;
            this.label16.Text = "A:";
            // 
            // lblDSPIErr
            // 
            this.lblDSPIErr.AutoSize = true;
            this.lblDSPIErr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDSPIErr.Location = new System.Drawing.Point(299, 92);
            this.lblDSPIErr.Name = "lblDSPIErr";
            this.lblDSPIErr.Size = new System.Drawing.Size(32, 13);
            this.lblDSPIErr.TabIndex = 19;
            this.lblDSPIErr.Text = "xxxxx";
            // 
            // lblDGyroY
            // 
            this.lblDGyroY.AutoSize = true;
            this.lblDGyroY.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDGyroY.Location = new System.Drawing.Point(299, 69);
            this.lblDGyroY.Name = "lblDGyroY";
            this.lblDGyroY.Size = new System.Drawing.Size(32, 13);
            this.lblDGyroY.TabIndex = 18;
            this.lblDGyroY.Text = "xxxxx";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(221, 92);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(51, 13);
            this.label19.TabIndex = 17;
            this.label19.Text = "SPI Err:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(221, 70);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 13);
            this.label20.TabIndex = 16;
            this.label20.Text = "Gyro Y:";
            // 
            // lblDGyroX
            // 
            this.lblDGyroX.AutoSize = true;
            this.lblDGyroX.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDGyroX.Location = new System.Drawing.Point(299, 48);
            this.lblDGyroX.Name = "lblDGyroX";
            this.lblDGyroX.Size = new System.Drawing.Size(32, 13);
            this.lblDGyroX.TabIndex = 15;
            this.lblDGyroX.Text = "xxxxx";
            // 
            // lblDGyro
            // 
            this.lblDGyro.AutoSize = true;
            this.lblDGyro.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDGyro.Location = new System.Drawing.Point(299, 25);
            this.lblDGyro.Name = "lblDGyro";
            this.lblDGyro.Size = new System.Drawing.Size(32, 13);
            this.lblDGyro.TabIndex = 14;
            this.lblDGyro.Text = "xxxxx";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(221, 48);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(49, 13);
            this.label23.TabIndex = 13;
            this.label23.Text = "Gyro X:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(221, 26);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(37, 13);
            this.label24.TabIndex = 12;
            this.label24.Text = "Gyro:";
            // 
            // lblDRoll
            // 
            this.lblDRoll.AutoSize = true;
            this.lblDRoll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDRoll.Location = new System.Drawing.Point(109, 137);
            this.lblDRoll.Name = "lblDRoll";
            this.lblDRoll.Size = new System.Drawing.Size(32, 13);
            this.lblDRoll.TabIndex = 11;
            this.lblDRoll.Text = "xxxxx";
            // 
            // lblDPitch
            // 
            this.lblDPitch.AutoSize = true;
            this.lblDPitch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDPitch.Location = new System.Drawing.Point(109, 114);
            this.lblDPitch.Name = "lblDPitch";
            this.lblDPitch.Size = new System.Drawing.Size(32, 13);
            this.lblDPitch.TabIndex = 10;
            this.lblDPitch.Text = "xxxxx";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(31, 137);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 13);
            this.label11.TabIndex = 9;
            this.label11.Text = "Roll:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(31, 115);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 13);
            this.label12.TabIndex = 8;
            this.label12.Text = "Pitch:";
            // 
            // lblDTemp
            // 
            this.lblDTemp.AutoSize = true;
            this.lblDTemp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDTemp.Location = new System.Drawing.Point(109, 92);
            this.lblDTemp.Name = "lblDTemp";
            this.lblDTemp.Size = new System.Drawing.Size(32, 13);
            this.lblDTemp.TabIndex = 7;
            this.lblDTemp.Text = "xxxxx";
            // 
            // lblDHeading
            // 
            this.lblDHeading.AutoSize = true;
            this.lblDHeading.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDHeading.Location = new System.Drawing.Point(109, 69);
            this.lblDHeading.Name = "lblDHeading";
            this.lblDHeading.Size = new System.Drawing.Size(32, 13);
            this.lblDHeading.TabIndex = 6;
            this.lblDHeading.Text = "xxxxx";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(31, 92);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Temp:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(31, 70);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Heading:";
            // 
            // lblDDepth
            // 
            this.lblDDepth.AutoSize = true;
            this.lblDDepth.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDDepth.Location = new System.Drawing.Point(109, 48);
            this.lblDDepth.Name = "lblDDepth";
            this.lblDDepth.Size = new System.Drawing.Size(32, 13);
            this.lblDDepth.TabIndex = 3;
            this.lblDDepth.Text = "xxxxx";
            // 
            // lblDLifeCount
            // 
            this.lblDLifeCount.AutoSize = true;
            this.lblDLifeCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDLifeCount.Location = new System.Drawing.Point(109, 25);
            this.lblDLifeCount.Name = "lblDLifeCount";
            this.lblDLifeCount.Size = new System.Drawing.Size(32, 13);
            this.lblDLifeCount.TabIndex = 2;
            this.lblDLifeCount.Text = "xxxxx";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Depth:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Life Count:";
            // 
            // cmdExit
            // 
            this.cmdExit.Location = new System.Drawing.Point(535, 10);
            this.cmdExit.Name = "cmdExit";
            this.cmdExit.Size = new System.Drawing.Size(90, 29);
            this.cmdExit.TabIndex = 5;
            this.cmdExit.Text = "Exit";
            this.cmdExit.UseVisualStyleBackColor = true;
            this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.cmdSendAsterisk);
            this.groupBox2.Controls.Add(this.udOutFormat);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.cmdSendR);
            this.groupBox2.Controls.Add(this.udOutRate);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.cmdSendS);
            this.groupBox2.Controls.Add(this.udDeguass);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.cmdSendA);
            this.groupBox2.Controls.Add(this.udAvgSamples);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 45);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(613, 147);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Compass Configuration";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(587, 116);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(11, 13);
            this.label14.TabIndex = 16;
            this.label14.Text = "*";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(586, 92);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(15, 13);
            this.label13.TabIndex = 15;
            this.label13.Text = "R";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(586, 67);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(14, 13);
            this.label10.TabIndex = 14;
            this.label10.Text = "S";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(587, 42);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "A";
            // 
            // cmdSendAsterisk
            // 
            this.cmdSendAsterisk.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdSendAsterisk.Location = new System.Drawing.Point(498, 113);
            this.cmdSendAsterisk.Name = "cmdSendAsterisk";
            this.cmdSendAsterisk.Size = new System.Drawing.Size(82, 21);
            this.cmdSendAsterisk.TabIndex = 12;
            this.cmdSendAsterisk.Text = "Send";
            this.cmdSendAsterisk.UseVisualStyleBackColor = true;
            this.cmdSendAsterisk.Click += new System.EventHandler(this.cmdSendAsterisk_Click);
            // 
            // udOutFormat
            // 
            this.udOutFormat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.udOutFormat.Location = new System.Drawing.Point(425, 114);
            this.udOutFormat.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.udOutFormat.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.udOutFormat.Name = "udOutFormat";
            this.udOutFormat.Size = new System.Drawing.Size(62, 20);
            this.udOutFormat.TabIndex = 11;
            this.udOutFormat.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(326, 116);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Output Format:";
            // 
            // cmdSendR
            // 
            this.cmdSendR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdSendR.Location = new System.Drawing.Point(498, 87);
            this.cmdSendR.Name = "cmdSendR";
            this.cmdSendR.Size = new System.Drawing.Size(82, 21);
            this.cmdSendR.TabIndex = 9;
            this.cmdSendR.Text = "Send";
            this.cmdSendR.UseVisualStyleBackColor = true;
            this.cmdSendR.Click += new System.EventHandler(this.cmdSendR_Click);
            // 
            // udOutRate
            // 
            this.udOutRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.udOutRate.Location = new System.Drawing.Point(425, 88);
            this.udOutRate.Maximum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.udOutRate.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.udOutRate.Name = "udOutRate";
            this.udOutRate.Size = new System.Drawing.Size(62, 20);
            this.udOutRate.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(326, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Output Rate:";
            // 
            // cmdSendS
            // 
            this.cmdSendS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdSendS.Location = new System.Drawing.Point(498, 63);
            this.cmdSendS.Name = "cmdSendS";
            this.cmdSendS.Size = new System.Drawing.Size(82, 21);
            this.cmdSendS.TabIndex = 6;
            this.cmdSendS.Text = "Send";
            this.cmdSendS.UseVisualStyleBackColor = true;
            this.cmdSendS.Click += new System.EventHandler(this.cmdSendS_Click);
            // 
            // udDeguass
            // 
            this.udDeguass.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.udDeguass.Location = new System.Drawing.Point(425, 64);
            this.udDeguass.Maximum = new decimal(new int[] {
            2400,
            0,
            0,
            0});
            this.udDeguass.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.udDeguass.Name = "udDeguass";
            this.udDeguass.Size = new System.Drawing.Size(62, 20);
            this.udDeguass.TabIndex = 5;
            this.udDeguass.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(326, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Deguass Every:";
            // 
            // cmdSendA
            // 
            this.cmdSendA.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdSendA.Location = new System.Drawing.Point(498, 37);
            this.cmdSendA.Name = "cmdSendA";
            this.cmdSendA.Size = new System.Drawing.Size(82, 21);
            this.cmdSendA.TabIndex = 3;
            this.cmdSendA.Text = "Send";
            this.cmdSendA.UseVisualStyleBackColor = true;
            this.cmdSendA.Click += new System.EventHandler(this.cmdSendA_Click);
            // 
            // udAvgSamples
            // 
            this.udAvgSamples.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.udAvgSamples.Location = new System.Drawing.Point(425, 38);
            this.udAvgSamples.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.udAvgSamples.Name = "udAvgSamples";
            this.udAvgSamples.Size = new System.Drawing.Size(62, 20);
            this.udAvgSamples.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(326, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Average Samples:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cmdSendX);
            this.groupBox3.Controls.Add(this.chkX05Depth);
            this.groupBox3.Controls.Add(this.chkX13SPI);
            this.groupBox3.Controls.Add(this.chkX12Life);
            this.groupBox3.Controls.Add(this.chkX11GyroVect);
            this.groupBox3.Controls.Add(this.chkX10Gyro);
            this.groupBox3.Controls.Add(this.chkX09AccVect);
            this.groupBox3.Controls.Add(this.chkX08Acc);
            this.groupBox3.Controls.Add(this.chkX07MagVect);
            this.groupBox3.Controls.Add(this.chkX06Mag);
            this.groupBox3.Controls.Add(this.chkX04Temp);
            this.groupBox3.Controls.Add(this.chkX03Roll);
            this.groupBox3.Controls.Add(this.chkX02Pitch);
            this.groupBox3.Controls.Add(this.chkX01Azimuth);
            this.groupBox3.Location = new System.Drawing.Point(15, 21);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(299, 119);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = " X Command";
            // 
            // cmdSendX
            // 
            this.cmdSendX.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdSendX.Location = new System.Drawing.Point(196, 87);
            this.cmdSendX.Name = "cmdSendX";
            this.cmdSendX.Size = new System.Drawing.Size(86, 21);
            this.cmdSendX.TabIndex = 13;
            this.cmdSendX.Text = "Send";
            this.cmdSendX.UseVisualStyleBackColor = true;
            this.cmdSendX.Click += new System.EventHandler(this.cmdSendX_Click);
            // 
            // chkX05Depth
            // 
            this.chkX05Depth.AutoSize = true;
            this.chkX05Depth.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkX05Depth.Location = new System.Drawing.Point(6, 78);
            this.chkX05Depth.Name = "chkX05Depth";
            this.chkX05Depth.Size = new System.Drawing.Size(55, 17);
            this.chkX05Depth.TabIndex = 12;
            this.chkX05Depth.Text = "Depth";
            this.chkX05Depth.UseVisualStyleBackColor = true;
            // 
            // chkX13SPI
            // 
            this.chkX13SPI.AutoSize = true;
            this.chkX13SPI.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkX13SPI.Location = new System.Drawing.Point(196, 62);
            this.chkX13SPI.Name = "chkX13SPI";
            this.chkX13SPI.Size = new System.Drawing.Size(59, 17);
            this.chkX13SPI.TabIndex = 11;
            this.chkX13SPI.Text = "SPI Err";
            this.chkX13SPI.UseVisualStyleBackColor = true;
            // 
            // chkX12Life
            // 
            this.chkX12Life.AutoSize = true;
            this.chkX12Life.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkX12Life.Location = new System.Drawing.Point(196, 48);
            this.chkX12Life.Name = "chkX12Life";
            this.chkX12Life.Size = new System.Drawing.Size(74, 17);
            this.chkX12Life.TabIndex = 10;
            this.chkX12Life.Text = "Life Count";
            this.chkX12Life.UseVisualStyleBackColor = true;
            // 
            // chkX11GyroVect
            // 
            this.chkX11GyroVect.AutoSize = true;
            this.chkX11GyroVect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkX11GyroVect.Location = new System.Drawing.Point(196, 33);
            this.chkX11GyroVect.Name = "chkX11GyroVect";
            this.chkX11GyroVect.Size = new System.Drawing.Size(73, 17);
            this.chkX11GyroVect.TabIndex = 9;
            this.chkX11GyroVect.Text = "Gyro Vect";
            this.chkX11GyroVect.UseVisualStyleBackColor = true;
            // 
            // chkX10Gyro
            // 
            this.chkX10Gyro.AutoSize = true;
            this.chkX10Gyro.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkX10Gyro.Location = new System.Drawing.Point(196, 19);
            this.chkX10Gyro.Name = "chkX10Gyro";
            this.chkX10Gyro.Size = new System.Drawing.Size(61, 17);
            this.chkX10Gyro.TabIndex = 8;
            this.chkX10Gyro.Text = "Gyro S.";
            this.chkX10Gyro.UseVisualStyleBackColor = true;
            // 
            // chkX09AccVect
            // 
            this.chkX09AccVect.AutoSize = true;
            this.chkX09AccVect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkX09AccVect.Location = new System.Drawing.Point(101, 62);
            this.chkX09AccVect.Name = "chkX09AccVect";
            this.chkX09AccVect.Size = new System.Drawing.Size(73, 17);
            this.chkX09AccVect.TabIndex = 7;
            this.chkX09AccVect.Text = "Acc. Vect";
            this.chkX09AccVect.UseVisualStyleBackColor = true;
            // 
            // chkX08Acc
            // 
            this.chkX08Acc.AutoSize = true;
            this.chkX08Acc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkX08Acc.Location = new System.Drawing.Point(101, 48);
            this.chkX08Acc.Name = "chkX08Acc";
            this.chkX08Acc.Size = new System.Drawing.Size(61, 17);
            this.chkX08Acc.TabIndex = 6;
            this.chkX08Acc.Text = "Acc. S.";
            this.chkX08Acc.UseVisualStyleBackColor = true;
            // 
            // chkX07MagVect
            // 
            this.chkX07MagVect.AutoSize = true;
            this.chkX07MagVect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkX07MagVect.Location = new System.Drawing.Point(101, 33);
            this.chkX07MagVect.Name = "chkX07MagVect";
            this.chkX07MagVect.Size = new System.Drawing.Size(63, 17);
            this.chkX07MagVect.TabIndex = 5;
            this.chkX07MagVect.Text = "M. Vect";
            this.chkX07MagVect.UseVisualStyleBackColor = true;
            // 
            // chkX06Mag
            // 
            this.chkX06Mag.AutoSize = true;
            this.chkX06Mag.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkX06Mag.Location = new System.Drawing.Point(101, 19);
            this.chkX06Mag.Name = "chkX06Mag";
            this.chkX06Mag.Size = new System.Drawing.Size(63, 17);
            this.chkX06Mag.TabIndex = 4;
            this.chkX06Mag.Text = "Mag. S.";
            this.chkX06Mag.UseVisualStyleBackColor = true;
            // 
            // chkX04Temp
            // 
            this.chkX04Temp.AutoSize = true;
            this.chkX04Temp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkX04Temp.Location = new System.Drawing.Point(6, 62);
            this.chkX04Temp.Name = "chkX04Temp";
            this.chkX04Temp.Size = new System.Drawing.Size(53, 17);
            this.chkX04Temp.TabIndex = 3;
            this.chkX04Temp.Text = "Temp";
            this.chkX04Temp.UseVisualStyleBackColor = true;
            // 
            // chkX03Roll
            // 
            this.chkX03Roll.AutoSize = true;
            this.chkX03Roll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkX03Roll.Location = new System.Drawing.Point(6, 48);
            this.chkX03Roll.Name = "chkX03Roll";
            this.chkX03Roll.Size = new System.Drawing.Size(44, 17);
            this.chkX03Roll.TabIndex = 2;
            this.chkX03Roll.Text = "Roll";
            this.chkX03Roll.UseVisualStyleBackColor = true;
            // 
            // chkX02Pitch
            // 
            this.chkX02Pitch.AutoSize = true;
            this.chkX02Pitch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkX02Pitch.Location = new System.Drawing.Point(6, 33);
            this.chkX02Pitch.Name = "chkX02Pitch";
            this.chkX02Pitch.Size = new System.Drawing.Size(50, 17);
            this.chkX02Pitch.TabIndex = 1;
            this.chkX02Pitch.Text = "Pitch";
            this.chkX02Pitch.UseVisualStyleBackColor = true;
            // 
            // chkX01Azimuth
            // 
            this.chkX01Azimuth.AutoSize = true;
            this.chkX01Azimuth.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkX01Azimuth.Location = new System.Drawing.Point(6, 19);
            this.chkX01Azimuth.Name = "chkX01Azimuth";
            this.chkX01Azimuth.Size = new System.Drawing.Size(63, 17);
            this.chkX01Azimuth.TabIndex = 0;
            this.chkX01Azimuth.Text = "Azimuth";
            this.chkX01Azimuth.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtMsgs);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(12, 374);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(612, 160);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Compass Messages";
            // 
            // txtMsgs
            // 
            this.txtMsgs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMsgs.Location = new System.Drawing.Point(14, 21);
            this.txtMsgs.Multiline = true;
            this.txtMsgs.Name = "txtMsgs";
            this.txtMsgs.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMsgs.Size = new System.Drawing.Size(583, 130);
            this.txtMsgs.TabIndex = 0;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(635, 546);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.cmdExit);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.cmdSetup);
            this.Controls.Add(this.cmdOpen);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Compass Demo";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.udOutFormat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.udOutRate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.udDeguass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.udAvgSamples)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdOpen;
        private System.Windows.Forms.Button cmdSetup;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button cmdExit;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDLifeCount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblDMagZ;
        private System.Windows.Forms.Label lblDMagY;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label lblDMagX;
        private System.Windows.Forms.Label lblDMag;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label lblDAccZ;
        private System.Windows.Forms.Label lblDAccY;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label lblDAccX;
        private System.Windows.Forms.Label lblDAcc;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblDSPIErr;
        private System.Windows.Forms.Label lblDGyroY;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lblDGyroX;
        private System.Windows.Forms.Label lblDGyro;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lblDRoll;
        private System.Windows.Forms.Label lblDPitch;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblDTemp;
        private System.Windows.Forms.Label lblDHeading;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblDDepth;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox chkX13SPI;
        private System.Windows.Forms.CheckBox chkX12Life;
        private System.Windows.Forms.CheckBox chkX11GyroVect;
        private System.Windows.Forms.CheckBox chkX10Gyro;
        private System.Windows.Forms.CheckBox chkX09AccVect;
        private System.Windows.Forms.CheckBox chkX08Acc;
        private System.Windows.Forms.CheckBox chkX07MagVect;
        private System.Windows.Forms.CheckBox chkX06Mag;
        private System.Windows.Forms.CheckBox chkX04Temp;
        private System.Windows.Forms.CheckBox chkX03Roll;
        private System.Windows.Forms.CheckBox chkX02Pitch;
        private System.Windows.Forms.CheckBox chkX01Azimuth;
        private System.Windows.Forms.Button cmdSendX;
        private System.Windows.Forms.CheckBox chkX05Depth;
        private System.Windows.Forms.Button cmdSendR;
        private System.Windows.Forms.NumericUpDown udOutRate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button cmdSendS;
        private System.Windows.Forms.NumericUpDown udDeguass;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button cmdSendA;
        private System.Windows.Forms.NumericUpDown udAvgSamples;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button cmdSendAsterisk;
        private System.Windows.Forms.NumericUpDown udOutFormat;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtMsgs;
    }
}

