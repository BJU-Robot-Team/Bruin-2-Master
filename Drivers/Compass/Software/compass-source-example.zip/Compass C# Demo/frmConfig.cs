using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

// Needed to handle Serial Port communications
using System.IO.Ports;

// Used to read exe properties (saved configuration)
using TestComPort.Properties;

namespace TestComPort
{
    public partial class frmConfig : Form
    {
        public frmConfig()
        {
            InitializeComponent();

            // Fill combo boxes
            // Get the parities names
            cmbParity.Items.AddRange(Enum.GetNames(typeof(Parity)));
            cmbStop.Items.AddRange(Enum.GetNames(typeof(StopBits)));

            cmbParity.Text = Settings.Default.Parity.ToString();
            cmbStop.Text = Settings.Default.StopBits.ToString();
            cmbData.Text = Settings.Default.DataBits.ToString();
            cmbParity.Text = Settings.Default.Parity.ToString();
            cmbBaud.Text = Settings.Default.BaudRate.ToString();

            // Get a list of available serial ports in the computer
            foreach (string s in SerialPort.GetPortNames())
                cmbPortName.Items.Add(s);

            if (cmbPortName.Items.Contains(Settings.Default.ComPort))
                cmbPortName.Text = Settings.Default.ComPort;
            else if (cmbPortName.Items.Count > 0)
                cmbPortName.SelectedIndex = 0;
            else
            {
                MessageBox.Show(this, "There are no COM Ports detected on this computer.\nPlease install a COM Port and try again.", "No COM Ports Installed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }


        }

        /// <summary>
        /// Save application configuration
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdOK_Click(object sender, EventArgs e)
        {
            Settings.Default.BaudRate = int.Parse(cmbBaud.Text);
            Settings.Default.DataBits = int.Parse(cmbData.Text);
            Settings.Default.Parity = (Parity)Enum.Parse(typeof(Parity), cmbParity.Text);
            Settings.Default.StopBits = (StopBits)Enum.Parse(typeof(StopBits), cmbStop.Text);
            Settings.Default.ComPort = cmbPortName.Text;

            Settings.Default.Save();

            // Close dialog
            DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}